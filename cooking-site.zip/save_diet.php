<?php session_start(); include 'db.php';
$data=json_decode(file_get_contents('php://input'), true);
if (!isset($_SESSION['username']) || !$data) exit;
$user=$_SESSION['username'];
$cal=intval($data['calories']);
$rest=$conn->real_escape_string($data['restrictions']);
$stmt=$conn->prepare("INSERT INTO diet_reports (username,calories,restrictions,date_recorded) VALUES (?,?,?,NOW())");
$stmt->bind_param("sis",$user,$cal,$rest); $stmt->execute();
echo "<p>Diet saved: {$cal} kcal/day. Restrictions: " . htmlspecialchars($rest) . "</p>";