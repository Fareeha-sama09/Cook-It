<?php session_start(); include 'db.php';
if (!isset($_SESSION['username']) || $_SESSION['username']!=='admin') { echo "Access denied."; exit; }
echo "<h2>All Users</h2>";
$u=$conn->query("SELECT id,username FROM users");
while($r=$u->fetch_assoc()) { echo "ID:{$r['id']} | User:".htmlspecialchars($r['username'])."<br>"; }

echo "<h2>All Recipes</h2>";
$rset=$conn->query("SELECT * FROM recipes");
while($r=$rset->fetch_assoc()) {
  echo "<strong>".htmlspecialchars($r['title'])."</strong> by ".
       htmlspecialchars($r['uploaded_by'])."<br>";
  echo "Ing: ".htmlspecialchars($r['ingredients'])."<br>";
  echo "Ins: ".htmlspecialchars($r['instructions'])."<hr>";
}