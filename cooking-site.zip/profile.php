<?php session_start(); include 'db.php';
if (!isset($_SESSION['username'])) header("Location: login.php");
$user = $_SESSION['username'];
echo "<h2>Profile: " . htmlspecialchars($user) . "</h2>";
echo "<p><a href='logout.php'>Logout</a></p>";

echo "<h3>Your Recipes</h3>";
$stmt = $conn->prepare("SELECT id,title FROM recipes WHERE uploaded_by=?");
$stmt->bind_param("s", $user); $stmt->execute();
$res = $stmt->get_result();
while ($r=$res->fetch_assoc()) {
  echo "<a href='recipe.php?id={$r['id']}'>" . htmlspecialchars($r['title']) . "</a><br>";
}

echo "<h3>Your Favorites</h3>";
$stmt = $conn->prepare("
 SELECT r.id,r.title FROM recipes r
 JOIN favorites f ON r.id=f.recipe_id
 WHERE f.username=?");
$stmt->bind_param("s", $user); $stmt->execute();
$res = $stmt->get_result();
while ($r=$res->fetch_assoc()) {
  echo "<a href='recipe.php?id={$r['id']}'>" . htmlspecialchars($r['title']) . "</a><br>";
}

echo "<h3>Diet Records</h3>";
$stmt = $conn->prepare("
  SELECT calories,restrictions,date_recorded
  FROM diet_reports WHERE username=?
  ORDER BY date_recorded DESC");
$stmt->bind_param("s",$user); $stmt->execute();
$res = $stmt->get_result();
while ($d=$res->fetch_assoc()) {
  echo "<p>{$d['date_recorded']}: {$d['calories']} kcal/day — " . nl2br(htmlspecialchars($d['restrictions'])) . "</p>";
}