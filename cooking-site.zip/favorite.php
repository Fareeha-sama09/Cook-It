<?php session_start(); include 'db.php';
if (!isset($_SESSION['username']) || $_SERVER['REQUEST_METHOD']!=="POST") exit;
$id=intval($_POST['recipe_id']);
$user=$_SESSION['username'];
$stmt=$conn->prepare("INSERT IGNORE INTO favorites (username,recipe_id) VALUES (?,?)");
$stmt->bind_param("si",$user,$id); $stmt->execute();