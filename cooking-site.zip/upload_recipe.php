<?php session_start(); include 'db.php';
if (!isset($_SESSION['username'])) header("Location: login.php");
if ($_SERVER["REQUEST_METHOD"]=="POST") {
  $title=$_POST['title']; $ing=$_POST['ingredients']; $inst=$_POST['instructions'];
  $user=$_SESSION['username'];
  $stmt=$conn->prepare("INSERT INTO recipes (title,ingredients,instructions,uploaded_by) VALUES(?,?,?,?)");
  $stmt->bind_param("ssss",$title,$ing,$inst,$user);
  $stmt->execute();
  echo "<p>Recipe uploaded!</p>";
}
?>
<form method="post"><h2>Upload Recipe</h2>
<input name="title" required placeholder="Title"/>
<textarea name="ingredients" required placeholder="Ingredients (comma-separated)"></textarea>
<textarea name="instructions" required placeholder="Instructions"></textarea>
<button type="submit">Upload</button>
</form>