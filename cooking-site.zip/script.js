function searchRecipe() {
  const input = document.getElementById("searchInput").value;
  document.getElementById("results").innerHTML =
    `<p>Results for "<strong>${input}</strong>":</p><ul><li>Sample Recipe A</li><li>Sample Recipe B</li></ul>`;
}

document.getElementById("dietForm").addEventListener("submit", function(e) {
  e.preventDefault();
  const form = e.target;
  fetch("save_diet.php", {
    method: "POST",
    headers: {"Content-Type": "application/json"},
    body: JSON.stringify({
      calories: form.calories.value,
      restrictions: form.restrictions.value
    })
  })
  .then(res => res.text())
  .then(html => document.getElementById("dietOutput").innerHTML = html);
});
