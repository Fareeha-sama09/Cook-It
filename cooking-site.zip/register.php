<?php include 'db.php';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $user = $_POST['username'];
  $pass = password_hash($_POST['password'], PASSWORD_DEFAULT);
  $stmt = $conn->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
  $stmt->bind_param("ss",$user,$pass); $stmt->execute();
  echo "Registered. <a href='login.php'>Login</a>"; exit;
}
?>
<form method="post"><h2>Register</h2>
<input name="username" required placeholder="Username"/>
<input type="password" name="password" required placeholder="Password"/>
<button type="submit">Register</button>
</form>