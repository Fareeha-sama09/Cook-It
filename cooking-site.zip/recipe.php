<?php session_start(); include 'db.php';
$id=intval($_GET['id']);
$stmt=$conn->prepare("SELECT * FROM recipes WHERE id=?");
$stmt->bind_param("i",$id); $stmt->execute();
$r=$stmt->get_result()->fetch_assoc();
?>
<h2><?= htmlspecialchars($r['title']) ?></h2>
<p><strong>By:</strong> <?= htmlspecialchars($r['uploaded_by']) ?></p>
<h3>Ingredients</h3><p><?= nl2br(htmlspecialchars($r['ingredients'])) ?></p>
<h3>Instructions</h3><p><?= nl2br(htmlspecialchars($r['instructions'])) ?></p>

<?php if(isset($_SESSION['username'])): ?>
<form action="favorite.php" method="post">
  <input type="hidden" name="recipe_id" value="<?= $id ?>">
  <button type="submit">Add to Favorites</button>
</form>
<?php endif; ?>