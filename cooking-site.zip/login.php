<?php session_start(); include 'db.php';
if ($_SERVER["REQUEST_METHOD"]=="POST") {
  $user=$_POST['username']; $pass=$_POST['password'];
  $stmt=$conn->prepare("SELECT password FROM users WHERE username=?");
  $stmt->bind_param("s",$user); $stmt->execute();
  $res=$stmt->get_result(); $row=$res->fetch_assoc();
  if ($row && password_verify($pass,$row['password'])) {
    $_SESSION['username']=$user;
    header("Location: dashboard.php"); exit;
  } else { echo "Invalid credentials"; }
}
?>
<form method="post"><h2>Login</h2>
<input name="username" required placeholder="Username"/>
<input type="password" name="password" required placeholder="Password"/>
<button type="submit">Login</button>
</form>