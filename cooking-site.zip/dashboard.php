<?php session_start();
if (!isset($_SESSION['username'])) header("Location: login.php");
echo "<h2>Welcome, " . htmlspecialchars($_SESSION['username']) . "!</h2>";
echo "<p><a href='profile.php'>View Profile</a> | <a href='upload_recipe.php'>Upload Recipe</a> | <a href='logout.php'>Logout</a></p>";